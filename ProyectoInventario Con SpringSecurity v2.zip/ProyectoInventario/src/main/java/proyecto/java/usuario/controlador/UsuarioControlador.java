package proyecto.java.usuario.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.validation.Valid;
import proyecto.java.usuario.modelo.Usuario;
import proyecto.java.usuario.servicio.RolSevicio;
import proyecto.java.usuario.servicio.UsuarioServicio;

@Controller
@RequestMapping("/views/usuario")
public class UsuarioControlador {

    @Autowired
    private UsuarioServicio usuarioServ;
    
    @Autowired
    private RolSevicio rolserv;
    

    @GetMapping("/")
    public String verIndex(Model model) {
        List<Usuario> listUsuarios = usuarioServ.getUsuarios();
        model.addAttribute("listUsuarios", listUsuarios);
        return "/views/usuario/usuario"; 
    }

    @GetMapping("/new")
    public String verPagNuevoUsuario(Model model) {
        Usuario u = new Usuario();
        model.addAttribute("nuevoUsuario", u);
        model.addAttribute("listaRoles", rolserv.getRoles());
        return "/views/usuario/nuevo_usuario";
    }

    @PostMapping("/save/new")
    public String saveUsuario(
            @Valid @ModelAttribute("nuevoUsuario") Usuario usuario,
            BindingResult result,
            @RequestParam(name = "rolesSeleccionados", required = false) List<Integer> rolesSeleccionados,
            Model model) {

        if (result.hasErrors()) {
            model.addAttribute("listaRoles", rolserv.getRoles());
            return "/views/usuario/nuevo_usuario";
        }

        if (usuarioServ.existeCorreo(usuario.getCorreo())) {
            result.rejectValue("correo", "error.usuario", "El correo ya está registrado.");
        }

        if (usuarioServ.existeUsuario(usuario.getUsuario())) {
            result.rejectValue("usuario", "error.usuario", "El nombre de usuario ya está en uso.");
        }

        if (result.hasErrors()) {
            model.addAttribute("listaRoles", rolserv.getRoles());
            return "/views/usuario/nuevo_usuario";
        }

        usuarioServ.nuevoUsuario(usuario, rolesSeleccionados);
        return "redirect:/views/usuario/";
    }


    @GetMapping("/editar/{id}")
    public String editarUsuario(@PathVariable(name = "id") int id, Model model) {
        Usuario usuario = usuarioServ.buscarUsuario(id);
        model.addAttribute("listaRoles", rolserv.getRoles());
        model.addAttribute("editarUsuario", usuario);
        return "/views/usuario/editar_usuario";
    }

    @PostMapping("/save/edit")
    public String editUsuario(
            @ModelAttribute("editarUsuario") Usuario usuario,  // 👈 sin @Valid
            BindingResult result,
            @RequestParam(name = "rolesSeleccionados", required = false) List<Integer> rolesSeleccionados,
            Model model) {

        System.out.println("🚩 [DEBUG] Iniciando edición de usuario ID=" + usuario.getId());

        Usuario usuarioExistente = usuarioServ.buscarUsuario(usuario.getId());
        if (usuarioExistente == null) {
            System.out.println("❌ [ERROR] No se encontró el usuario en la base de datos.");
            return "redirect:/views/usuario/";
        }

        if (usuario.getNombre() == null || usuario.getNombre().isBlank()) {
            result.rejectValue("nombre", "error.nombre", "El nombre es obligatorio.");
        }

        if (usuario.getApellido() == null || usuario.getApellido().isBlank()) {
            result.rejectValue("apellido", "error.apellido", "El apellido es obligatorio.");
        }

        if (usuario.getCorreo() == null || usuario.getCorreo().isBlank()) {
            result.rejectValue("correo", "error.correo", "El correo electrónico es obligatorio.");
        }

        if (usuario.getDireccion() == null || usuario.getDireccion().isBlank()) {
            result.rejectValue("direccion", "error.direccion", "La dirección es obligatoria.");
        }

        if (usuario.getUsuario() == null || usuario.getUsuario().isBlank()) {
            result.rejectValue("usuario", "error.usuario", "El nombre de usuario es obligatorio.");
        }

        if (!usuario.getCorreo().equalsIgnoreCase(usuarioExistente.getCorreo()) &&
            usuarioServ.existeCorreo(usuario.getCorreo())) {
            result.rejectValue("correo", "error.correo", "El correo ya está registrado.");
        }

        if (!usuario.getUsuario().equalsIgnoreCase(usuarioExistente.getUsuario()) &&
            usuarioServ.existeUsuario(usuario.getUsuario())) {
            result.rejectValue("usuario", "error.usuario", "El nombre de usuario ya está en uso.");
        }

        if (usuario.getContrasena() == null || usuario.getContrasena().isBlank()) {
            usuario.setContrasena(usuarioExistente.getContrasena());
        } else {
            usuario.setContrasena(usuarioServ.encriptarContrasena(usuario.getContrasena()));
        }


        if (result.hasErrors()) {
            System.out.println("⚠️ [DEBUG] Errores detectados: " + result.getAllErrors());
            model.addAttribute("listaRoles", rolserv.getRoles());
            model.addAttribute("editarUsuario", usuario);
            return "/views/usuario/editar_usuario";
        }

        // ✅ Asegurar ID y roles
        usuario.setId(usuarioExistente.getId());
        usuarioServ.guardarUsuario(usuario, rolesSeleccionados);

        System.out.println("✅ [DEBUG] Usuario actualizado correctamente: " + usuario.getUsuario());
        return "redirect:/views/usuario/";
    }



    @RequestMapping("/delete/{id}")
    public String deleteUsuario(@PathVariable(name = "id") int id, Model model) {
        try {
            usuarioServ.borrarUsuario(id);
            return "redirect:/views/usuario/";
        } catch (DataIntegrityViolationException ex) {
            model.addAttribute("errorTitulo", "Error al eliminar usuario");
            model.addAttribute("volver", "/views/usuario/");
            model.addAttribute("pagina", "Usuarios");
            model.addAttribute("errorMensaje", "No se puede eliminar el usuario porque tiene datos asociados.");
            model.addAttribute("errorDetalle", ex.getMostSpecificCause().getMessage());
            return "fallo";
        }
    }
}
