package proyecto.java.usuario.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import proyecto.java.usuario.modelo.Cliente;

public interface ClienteRepositorio extends JpaRepository<Cliente, Integer> {

}
