package proyecto.java.usuario.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = Venta.TABLE_NAME)
public class Venta {
    
    private static final String TABLE_NAME = "ventas";
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "v_id_venta")
    private int id;

    @NotNull(message = "Debe seleccionar un producto")
    @ManyToOne
    @JoinColumn(name = "v_id_producto", nullable = false)
    private Producto producto;

    @NotNull(message = "Debe seleccionar un cliente")
    @ManyToOne
    @JoinColumn(name = "v_id_cliente", nullable = false)
    private Cliente cliente;

    @NotBlank(message = "El estado de pago es obligatorio")
    @Size(max = 20)
    @Column(name = "v_estado_pago")
    private String estadoPago;

    @NotNull(message = "La cantidad es obligatoria")
    @Min(value = 1, message = "La cantidad debe ser al menos 1")
    @Column(name = "v_cantidad")
    private int cantidad;

    @Min(value = 0, message = "El precio no puede ser negativo")
    @Column(name = "v_precio_u")
    private double precioUnitario;

    @Size(max = 50)
    @Column(name = "v_ciudad_envio")
    private String ciudadEnvio;

    @Size(max = 150)
    @Column(name = "v_direccion_envio")
    private String direccionEnvio;

    @Column(name = "v_Total")
    private double total;

    @Size(max = 100)
    @Column(name = "v_correo")
    private String correo;

    @Size(max = 20)
    @Column(name = "v_estado_despacho")
    private String estadoDespacho;

    // Constructor vacío
    public Venta() {
        super();
    }

    // Constructor con parámetros
    public Venta(int id, Producto producto, Cliente cliente, String estadoPago, int cantidad, 
                 double precioUnitario, String ciudadEnvio, String direccionEnvio, double total, 
                 String correo, String estadoDespacho) {
        this.id = id;
        this.producto = producto;
        this.cliente = cliente;
        this.estadoPago = estadoPago;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.ciudadEnvio = ciudadEnvio;
        this.direccionEnvio = direccionEnvio;
        this.total = total;
        this.correo = correo;
        this.estadoDespacho = estadoDespacho;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getEstadoPago() {
        return estadoPago;
    }

    public void setEstadoPago(String estadoPago) {
        this.estadoPago = estadoPago;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public String getCiudadEnvio() {
        return ciudadEnvio;
    }

    public void setCiudadEnvio(String ciudadEnvio) {
        this.ciudadEnvio = ciudadEnvio;
    }

    public String getDireccionEnvio() {
        return direccionEnvio;
    }

    public void setDireccionEnvio(String direccionEnvio) {
        this.direccionEnvio = direccionEnvio;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getEstadoDespacho() {
        return estadoDespacho;
    }

    public void setEstadoDespacho(String estadoDespacho) {
        this.estadoDespacho = estadoDespacho;
    }

    @Override
    public String toString() {
        return "Venta [id=" + id + ", producto=" + producto + ", cliente=" + cliente + 
               ", estadoPago=" + estadoPago + ", cantidad=" + cantidad + ", precioUnitario=" + 
               precioUnitario + ", ciudadEnvio=" + ciudadEnvio + ", direccionEnvio=" + 
               direccionEnvio + ", total=" + total + ", correo=" + correo + 
               ", estadoDespacho=" + estadoDespacho + "]";
    }
}
