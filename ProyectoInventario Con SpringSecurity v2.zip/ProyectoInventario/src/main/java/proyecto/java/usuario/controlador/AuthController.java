package proyecto.java.usuario.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import proyecto.java.usuario.modelo.JwtResponse;
import proyecto.java.usuario.modelo.LoginRequest;
import proyecto.java.usuario.modelo.Usuario;
import proyecto.java.usuario.seguridad.JwtUtil;
import proyecto.java.usuario.servicio.UsuarioServicio;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

	    @Autowired
	    private UsuarioServicio usuarioServicio;

	    @Autowired
	    private JwtUtil jwtUtil;

	    @PostMapping("/login")
	    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
	        Usuario usuario = usuarioServicio.buscarPorCorreoOUsuario(request.getUsername());
	        
	        if (usuario == null || !usuarioServicio.passwordMatches(request.getPassword(), usuario.getContrasena())) {
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Credenciales inválidas");
	        }

	        String token = jwtUtil.generarToken(usuario.getCorreo());
	        return ResponseEntity.ok(new JwtResponse(token));
	    }

	
}
