package proyecto.java.usuario.servicio;

import java.util.List;

import proyecto.java.usuario.modelo.Rol;

public interface IRolServicio {

	public List<Rol> getRoles();
	
}
