package proyecto.java.usuario.servicio;

import java.util.List;
import proyecto.java.usuario.modelo.Cliente;

public interface IClienteServicio {
    
    public List<Cliente> getClientes();
    
    public void nuevoCliente(Cliente cliente);
    
    public Cliente buscarCliente(Integer id);
    
    public void borrarCliente(Integer id);
}
