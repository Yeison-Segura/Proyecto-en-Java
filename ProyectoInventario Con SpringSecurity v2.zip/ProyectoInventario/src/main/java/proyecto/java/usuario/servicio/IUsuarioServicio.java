package proyecto.java.usuario.servicio;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;
import proyecto.java.usuario.modelo.Usuario;

public interface IUsuarioServicio extends UserDetailsService{
    
    public List<Usuario> getUsuarios();
    
    public void nuevoUsuario(Usuario usuario, List<Integer> rolesSeleccionados);
    
    public Usuario buscarUsuario(Integer id);
    
    public void borrarUsuario(Integer id);
}
