package proyecto.java.usuario.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import proyecto.java.usuario.modelo.Rol;


public interface RolRepositorio extends JpaRepository<Rol, Integer>{
	public Rol findByNombre(String nombre); 
}
