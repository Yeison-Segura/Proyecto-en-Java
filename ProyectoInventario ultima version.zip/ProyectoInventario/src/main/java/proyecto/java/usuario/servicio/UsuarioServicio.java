package proyecto.java.usuario.servicio;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import proyecto.java.usuario.modelo.Rol;
import proyecto.java.usuario.modelo.Usuario;
import proyecto.java.usuario.repositorio.RolRepositorio;
import proyecto.java.usuario.repositorio.UsuarioRepositorio;

@Service
@Transactional
public class UsuarioServicio implements IUsuarioServicio {
	
    private final UsuarioRepositorio usuarioRep;
    private final BCryptPasswordEncoder passwordEncoder;
    private final RolRepositorio rolRep;

    public UsuarioServicio(UsuarioRepositorio usuarioRep, RolRepositorio rolRep, BCryptPasswordEncoder passwordEncoder) {
        this.usuarioRep = usuarioRep;
        this.rolRep = rolRep;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public List<Usuario> getUsuarios() {
        return usuarioRep.findAll();
    }

    @Override
    public void nuevoUsuario(Usuario usuario, List<Integer> rolesSeleccionados) {

        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));

        if (rolesSeleccionados == null || rolesSeleccionados.isEmpty()) {
            Rol rolPorDefecto = rolRep.findByNombre("USUARIO");
            usuario.setRoles(List.of(rolPorDefecto));
        } else {
            List<Rol> roles = rolRep.findAllById(rolesSeleccionados);
            usuario.setRoles(roles);
        }

        usuarioRep.save(usuario);
    }


    @Override
    public Usuario buscarUsuario(Integer id) {
        return usuarioRep.findById(id).orElse(null);
    }

    @Override
    public void borrarUsuario(Integer id) {
        usuarioRep.deleteById(id);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Usuario usuario = usuarioRep.findByCorreo(username);

        if (usuario == null) {
            usuario = usuarioRep.findByUsuario(username);
        }

        if (usuario == null) {
            throw new UsernameNotFoundException("Usuario o contraseña inválidos");
        }

        return new User(
            usuario.getNombre(),
            usuario.getContrasena(),
            listarAutoridades(usuario.getRoles())
        );
    }

    private Collection<? extends GrantedAuthority> listarAutoridades(Collection<Rol> roles) {
        return roles.stream()
                .map(rol -> new SimpleGrantedAuthority("ROLE_" + rol.getNombre()))
                .collect(Collectors.toList());
    }
    
    public void guardarUsuario(Usuario usuario,List<Integer> rolesSeleccionados) {
    	if (rolesSeleccionados == null || rolesSeleccionados.isEmpty()) {
            Rol rolPorDefecto = rolRep.findByNombre("USUARIO");
            usuario.setRoles(List.of(rolPorDefecto));
        } else {
            List<Rol> roles = rolRep.findAllById(rolesSeleccionados);
            usuario.setRoles(roles);
        }
        usuarioRep.save(usuario);
    }
    
    public String encriptarContrasena(String contrasena) {
        return passwordEncoder.encode(contrasena);
    }
    
    public Usuario buscarPorCorreoOUsuario(String valor) {
        Usuario usuario = usuarioRep.findByCorreo(valor);
        if (usuario == null) {
            usuario = usuarioRep.findByUsuario(valor);
        }
        return usuario;
    }
    
    public boolean passwordMatches(String rawPassword, String encodedPassword) {
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }
    
    public boolean existeCorreo(String correo) {
        return usuarioRep.findByCorreo(correo) != null;
    }

    public boolean existeUsuario(String nombreUsuario) {
        return usuarioRep.findByUsuario(nombreUsuario) != null;
    }

}
