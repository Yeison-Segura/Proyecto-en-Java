package proyecto.java.usuario.seguridad;

import java.security.Key;
import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {

    // 🔑 Clave secreta (NO cambies entre reinicios si quieres mantener tokens válidos)
    private final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256);

    // ⏰ Duración del token (1 día = 86400000 ms)
    private final long EXPIRATION_TIME = 86400000;

    public String generarToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(key)
                .compact();
    }

    public String obtenerUsuarioDeToken(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    public boolean validarToken(String token) {
        try {
            Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token);
            return true;
        } catch (io.jsonwebtoken.ExpiredJwtException e) {
            System.out.println("❌ Token expirado");
            return false;
        } catch (io.jsonwebtoken.JwtException e) {
            System.out.println("❌ Token inválido");
            return false;
        }
    }
}