package proyecto.java.usuario.modelo;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = Venta.TABLE_NAME)
public class Venta {
    
    private static final String TABLE_NAME = "ventas";
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "v_id_venta")
    private int id;

    @NotNull(message = "Debe seleccionar un cliente")
    @ManyToOne
    @JoinColumn(name = "v_id_cliente", nullable = false)
    private Cliente cliente;

    @NotBlank(message = "El estado de pago es obligatorio")
    @Size(max = 20)
    @Column(name = "v_estado_pago")
    private String estadoPago;

    @Size(max = 50)
    @Column(name = "v_ciudad_envio")
    private String ciudadEnvio;

    @Size(max = 150)
    @Column(name = "v_direccion_envio")
    private String direccionEnvio;

    @Column(name = "v_Total")
    private double total;

    @Size(max = 100)
    @Column(name = "v_correo")
    private String correo;

    @Size(max = 20)
    @Column(name = "v_estado_despacho")
    private String estadoDespacho;
    
    @OneToMany(mappedBy = "venta", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleVenta> detalles = new ArrayList<>();

    // Constructor vacío
    public Venta() {
        super();
    }

    // Constructor con parámetros
    public Venta(int id, Cliente cliente, String estadoPago, String ciudadEnvio, 
                 String direccionEnvio, double total, String correo, String estadoDespacho) {
        this.id = id;
        this.cliente = cliente;
        this.estadoPago = estadoPago;
        this.ciudadEnvio = ciudadEnvio;
        this.direccionEnvio = direccionEnvio;
        this.total = total;
        this.correo = correo;
        this.estadoDespacho = estadoDespacho;
    }

    // Método para agregar detalle
    public void agregarDetalle(DetalleVenta detalle) {
        detalles.add(detalle);
        detalle.setVenta(this);
    }

    // Método para calcular total
    public void calcularTotal() {
        this.total = detalles.stream()
                            .mapToDouble(DetalleVenta::getSubtotal)
                            .sum();
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getEstadoPago() {
        return estadoPago;
    }

    public void setEstadoPago(String estadoPago) {
        this.estadoPago = estadoPago;
    }

    public String getCiudadEnvio() {
        return ciudadEnvio;
    }

    public void setCiudadEnvio(String ciudadEnvio) {
        this.ciudadEnvio = ciudadEnvio;
    }

    public String getDireccionEnvio() {
        return direccionEnvio;
    }

    public void setDireccionEnvio(String direccionEnvio) {
        this.direccionEnvio = direccionEnvio;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getEstadoDespacho() {
        return estadoDespacho;
    }

    public void setEstadoDespacho(String estadoDespacho) {
        this.estadoDespacho = estadoDespacho;
    }

    public List<DetalleVenta> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetalleVenta> detalles) {
        this.detalles = detalles;
    }

    @Override
    public String toString() {
        return "Venta [id=" + id + ", cliente=" + cliente + ", estadoPago=" + estadoPago + 
               ", ciudadEnvio=" + ciudadEnvio + ", direccionEnvio=" + direccionEnvio + 
               ", total=" + total + ", correo=" + correo + ", estadoDespacho=" + estadoDespacho + "]";
    }
}