package proyecto.java.usuario.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import proyecto.java.usuario.modelo.Cliente;
import proyecto.java.usuario.repositorio.ClienteRepositorio;

@Service
@Transactional
public class ClienteServicio implements IClienteServicio {
    
    @Autowired
    private ClienteRepositorio clienteRep;
    
    @Override
    public List<Cliente> getClientes() {
        return clienteRep.findAll();
    }

    @Override
    public void nuevoCliente(Cliente cliente) {
        clienteRep.save(cliente);
    }

    @Override
    public Cliente buscarCliente(Integer id) {
        return clienteRep.findById(id).orElse(null);
    }

    @Override
    public void borrarCliente(Integer id) {
        clienteRep.deleteById(id);
    }
}
