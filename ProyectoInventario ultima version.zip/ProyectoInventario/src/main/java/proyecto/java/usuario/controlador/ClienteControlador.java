package proyecto.java.usuario.controlador;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import jakarta.validation.Valid;
import proyecto.java.usuario.modelo.Cliente;
import proyecto.java.usuario.servicio.ClienteServicio;

@Controller
@RequestMapping("/views/cliente")
public class ClienteControlador {
    
    @Autowired
    private ClienteServicio clienteServ;

    @GetMapping("/")
    public String verIndex(Model model) {
        List<Cliente> listClientes = clienteServ.getClientes();
        model.addAttribute("listClientes", listClientes);
        return "/views/cliente/cliente";
    }

    @GetMapping("/new")
    public String verPagNuevoCliente(Model model) {
        Cliente c = new Cliente();
        model.addAttribute("cliente", c);
        return "/views/cliente/nuevo_cliente";
    }

    @PostMapping("/save/new")
    public String saveCliente(@Valid @ModelAttribute("cliente") Cliente cliente,
                              BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "/views/cliente/nuevo_cliente";
        }
        clienteServ.nuevoCliente(cliente);
        return "redirect:/views/cliente/";
    }

    @GetMapping("/editar/{id}")
    public String editarCliente(@PathVariable(name = "id") int id, Model model) {
        Cliente cliente = clienteServ.buscarCliente(id);
        model.addAttribute("cliente", cliente);
        return "/views/cliente/editar_cliente";
    }

    @PostMapping("/save/edit")
    public String editCliente(@Valid @ModelAttribute("cliente") Cliente cliente,
                              BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "/views/cliente/editar_cliente";
        }
        clienteServ.nuevoCliente(cliente);
        return "redirect:/views/cliente/";
    }

    @RequestMapping("/delete/{id}")
    public String deleteCliente(@PathVariable(name = "id") int id, Model model) {
        try {
            clienteServ.borrarCliente(id);
            return "redirect:/views/cliente/";
        } catch (DataIntegrityViolationException ex) {
            model.addAttribute("errorTitulo", "Error al eliminar cliente");
            model.addAttribute("volver", "/views/cliente/");
            model.addAttribute("pagina", "Clientes");
            model.addAttribute("errorMensaje", "No se puede eliminar el cliente porque tiene ventas asociadas.");
            model.addAttribute("errorDetalle", ex.getMostSpecificCause().getMessage());
            return "fallo";
        }
    }
}
