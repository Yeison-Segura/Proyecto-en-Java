package proyecto.java.usuario.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import proyecto.java.usuario.modelo.DetalleVenta;
import proyecto.java.usuario.modelo.Producto;
import proyecto.java.usuario.modelo.Venta;
import proyecto.java.usuario.servicio.ClienteServicio;
import proyecto.java.usuario.servicio.ProductoServicio;
import proyecto.java.usuario.servicio.VentaServicio;

@Controller
@RequestMapping("/views/venta")
public class VentaControlador {
    
    @Autowired
    private VentaServicio ventaServ;
    
    @Autowired
    private ProductoServicio prodServ;
    
    @Autowired
    private ClienteServicio clienteServ;
    
    @GetMapping("/")
    public String verIndex(Model model) {
        var ventas = ventaServ.getVentas();
        model.addAttribute("listVentas", ventas);
        return "/views/venta/venta";
    }
    
    @GetMapping("/new")
    public String verPagNuevaVenta(Model model) {
        Venta v = new Venta();
        var listProductos = prodServ.getProductos();
        var listClientes = clienteServ.getClientes();
        model.addAttribute("listProductos", listProductos);
        model.addAttribute("listClientes", listClientes);
        model.addAttribute("venta", v);
        return "/views/venta/nueva_venta";
    }
    
    @PostMapping("/save/new")
    public String saveVenta(@Valid @ModelAttribute("venta") Venta venta,
                           BindingResult result,
                           @RequestParam(value = "productosIds", required = false) int[] productosIds,
                           @RequestParam(value = "cantidades", required = false) int[] cantidades,
                           Model model) {
        
        if (result.hasErrors()) {
            var listProductos = prodServ.getProductos();
            var listClientes = clienteServ.getClientes();
            model.addAttribute("listProductos", listProductos);
            model.addAttribute("listClientes", listClientes);
            return "/views/venta/nueva_venta";
        }
        
        // Validar que se hayan seleccionado productos
        if (productosIds == null || productosIds.length == 0) {
            var listProductos = prodServ.getProductos();
            var listClientes = clienteServ.getClientes();
            model.addAttribute("listProductos", listProductos);
            model.addAttribute("listClientes", listClientes);
            model.addAttribute("error", "Debe seleccionar al menos un producto");
            return "/views/venta/nueva_venta";
        }
        
        // Crear detalles de venta
        for (int i = 0; i < productosIds.length; i++) {
            Producto producto = prodServ.buscarProducto(productosIds[i]);
            if (producto != null && cantidades[i] > 0) {
                DetalleVenta detalle = new DetalleVenta();
                detalle.setProducto(producto);
                detalle.setCantidad(cantidades[i]);
                detalle.setPrecioUnitario(producto.getPrecio());
                detalle.setSubtotal(producto.getPrecio() * cantidades[i]);
                venta.agregarDetalle(detalle);
            }
        }
        
        // Calcular total
        venta.calcularTotal();
        
        ventaServ.nuevaVenta(venta);
        return "redirect:/views/venta/";
    }
    
    @GetMapping("/editar/{id}")
    public String editarVenta(@PathVariable(name = "id") int id, Model model) {
        var listProductos = prodServ.getProductos();
        var listClientes = clienteServ.getClientes();
        model.addAttribute("listProductos", listProductos);
        model.addAttribute("listClientes", listClientes);
        model.addAttribute("venta", ventaServ.buscarVenta(id));
        return "/views/venta/editar_venta";
    }
    
    @PostMapping("/save/edit")
    public String editVenta(@Valid @ModelAttribute("venta") Venta venta,
                           BindingResult result,
                           @RequestParam(value = "productosIds", required = false) int[] productosIds,
                           @RequestParam(value = "cantidades", required = false) int[] cantidades,
                           Model model) {
        
        if (result.hasErrors()) {
            var listProductos = prodServ.getProductos();
            var listClientes = clienteServ.getClientes();
            model.addAttribute("listProductos", listProductos);
            model.addAttribute("listClientes", listClientes);
            return "/views/venta/editar_venta";
        }
        
        // Limpiar detalles antiguos
        venta.getDetalles().clear();
        
        // Agregar nuevos detalles si se proporcionaron
        if (productosIds != null && productosIds.length > 0) {
            for (int i = 0; i < productosIds.length; i++) {
                Producto producto = prodServ.buscarProducto(productosIds[i]);
                if (producto != null && cantidades[i] > 0) {
                    DetalleVenta detalle = new DetalleVenta();
                    detalle.setProducto(producto);
                    detalle.setCantidad(cantidades[i]);
                    detalle.setPrecioUnitario(producto.getPrecio());
                    detalle.setSubtotal(producto.getPrecio() * cantidades[i]);
                    venta.agregarDetalle(detalle);
                }
            }
        }
        
        // Calcular total
        venta.calcularTotal();
        
        ventaServ.nuevaVenta(venta);
        return "redirect:/views/venta/";
    }
    
    @RequestMapping("/delete/{id}")
    public String deleteVenta(@PathVariable(name = "id") int id, Model model) {
        try {
            ventaServ.borrarVenta(id);
            return "redirect:/views/venta/";
        } catch (DataIntegrityViolationException ex) {
            model.addAttribute("errorTitulo", "Error al eliminar venta");
            model.addAttribute("volver", "/views/venta/");
            model.addAttribute("pagina", "Ventas");
            model.addAttribute("errorMensaje", "No se puede eliminar la venta.");
            model.addAttribute("errorDetalle", ex.getMostSpecificCause().getMessage());
            return "fallo";
        }
    }
}