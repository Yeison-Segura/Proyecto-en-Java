package proyecto.java.usuario.dto;

public class UsuarioRegistroDTO {
	private int id;
	private String nombre;
	private String apellido;
	private String correo;
	private String direccion;
	private String usuario;
	private String contrasena;
	private String tipoAcceso;
	
	public UsuarioRegistroDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public UsuarioRegistroDTO(String nombre, String apellido, String correo, String direccion, String usuario,
			String contrasena, String tipoAcceso) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.correo = correo;
		this.direccion = direccion;
		this.usuario = usuario;
		this.contrasena = contrasena;
		this.tipoAcceso = tipoAcceso;
	}

	public UsuarioRegistroDTO(String correo) {
		super();
		this.correo = correo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getContrasena() {
		return contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	public String getTipoAcceso() {
		return tipoAcceso;
	}

	public void setTipoAcceso(String tipoAcceso) {
		this.tipoAcceso = tipoAcceso;
	}
	
	
	
}
