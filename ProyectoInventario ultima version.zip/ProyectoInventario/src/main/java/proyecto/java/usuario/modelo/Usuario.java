package proyecto.java.usuario.modelo;

import java.util.Collection;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = Usuario.TABLE_NAME)
public class Usuario {
    
    // Nombre de la tabla en la base de datos
    public static final String TABLE_NAME = "usuario";

    // Clave primaria
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "u_id")
    private int id;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 50, message = "El nombre no puede tener más de 50 caracteres")
    @Column(name = "u_nombre", nullable = false, length = 50)
    private String nombre;

    @NotBlank(message = "El apellido es obligatorio")
    @Size(max = 50, message = "El apellido no puede tener más de 50 caracteres")
    @Column(name = "u_apellido", nullable = false, length = 50)
    private String apellido;

    @NotBlank(message = "El correo es obligatorio")
    @Email(message = "Debe ingresar un correo electrónico válido")
    @Size(max = 100, message = "El correo no puede tener más de 100 caracteres")
    @Column(name = "u_correo", nullable = false, length = 100, unique = true)
    private String correo;

    @NotBlank(message = "La dirección es obligatoria")
    @Size(max = 150, message = "La dirección no puede tener más de 150 caracteres")
    @Column(name = "u_direccion", nullable = false, length = 150)
    private String direccion;

    @NotBlank(message = "El nombre de usuario es obligatorio")
    @Size(max = 30, message = "El nombre de usuario no puede tener más de 30 caracteres")
    @Column(name = "u_usuario", nullable = false, length = 30, unique = true)
    private String usuario;

    @NotBlank(message = "La contraseña es obligatoria")
    @Size(min = 6, max = 100, message = "La contraseña debe tener entre 6 y 100 caracteres")
    @Column(name = "u_contrasena", nullable = false, length = 100)
    private String contrasena;

    // Constructor vacío
    public Usuario() {
        super();
    }
    
    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinTable(
        name = "usuario_rol",
        joinColumns = @JoinColumn(name = "u_id", referencedColumnName = "u_id"),
        inverseJoinColumns = @JoinColumn(name = "r_id", referencedColumnName = "r_id")
    )
    private Collection<Rol> roles;


	public Usuario(
			@NotBlank(message = "El nombre es obligatorio") @Size(max = 50, message = "El nombre no puede tener más de 50 caracteres") String nombre,
			@NotBlank(message = "El apellido es obligatorio") @Size(max = 50, message = "El apellido no puede tener más de 50 caracteres") String apellido,
			@NotBlank(message = "El correo es obligatorio") @Email(message = "Debe ingresar un correo electrónico válido") @Size(max = 100, message = "El correo no puede tener más de 100 caracteres") String correo,
			@NotBlank(message = "La dirección es obligatoria") @Size(max = 150, message = "La dirección no puede tener más de 150 caracteres") String direccion,
			@NotBlank(message = "El nombre de usuario es obligatorio") @Size(max = 30, message = "El nombre de usuario no puede tener más de 30 caracteres") String usuario,
			@NotBlank(message = "La contraseña es obligatoria") @Size(min = 6, max = 100, message = "La contraseña debe tener entre 6 y 100 caracteres") String contrasena,
			Collection<Rol> roles) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.correo = correo;
		this.direccion = direccion;
		this.usuario = usuario;
		this.contrasena = contrasena;
		this.roles = roles;
	}

	public Usuario(int id,
			@NotBlank(message = "El nombre es obligatorio") @Size(max = 50, message = "El nombre no puede tener más de 50 caracteres") String nombre,
			@NotBlank(message = "El apellido es obligatorio") @Size(max = 50, message = "El apellido no puede tener más de 50 caracteres") String apellido,
			@NotBlank(message = "El correo es obligatorio") @Email(message = "Debe ingresar un correo electrónico válido") @Size(max = 100, message = "El correo no puede tener más de 100 caracteres") String correo,
			@NotBlank(message = "La dirección es obligatoria") @Size(max = 150, message = "La dirección no puede tener más de 150 caracteres") String direccion,
			@NotBlank(message = "El nombre de usuario es obligatorio") @Size(max = 30, message = "El nombre de usuario no puede tener más de 30 caracteres") String usuario,
			@NotBlank(message = "La contraseña es obligatoria") @Size(min = 6, max = 100, message = "La contraseña debe tener entre 6 y 100 caracteres") String contrasena,
			Collection<Rol> roles) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.correo = correo;
		this.direccion = direccion;
		this.usuario = usuario;
		this.contrasena = contrasena;
		this.roles = roles;
	}

	// Getters y Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getContrasena() {
		return contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	public Collection<Rol> getRoles() {
		return roles;
	}

	public void setRoles(Collection<Rol> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", correo=" + correo
				+ ", direccion=" + direccion + ", usuario=" + usuario + ", contrasena=" + contrasena + ", roles="
				+ roles + "]";
	}
	
}
