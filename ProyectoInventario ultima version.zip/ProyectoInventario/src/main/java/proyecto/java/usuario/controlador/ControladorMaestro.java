package proyecto.java.usuario.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.validation.Valid;
import proyecto.java.usuario.modelo.Usuario;
import proyecto.java.usuario.servicio.UsuarioServicio;

@Controller
@RequestMapping("/")
public class ControladorMaestro {
	
    @Autowired
    private UsuarioServicio usuarioServicio;

    @GetMapping("/")
    public String index() {
        return "home";
    }

    @GetMapping("/index")
    public String bienvenido() {
        return "index";
    }

    @GetMapping("/login")
    public String mostrarLogin() {
        return "login";
    }

    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
        model.addAttribute("user", new Usuario());
        return "registro";
    }

    @PostMapping("/registro")
    public String registrarUsuario(@Valid @ModelAttribute("user") Usuario user,
                                   BindingResult result,
                                   Model model) {
        try {
            if (usuarioServicio.existeCorreo(user.getCorreo())) {
                result.rejectValue("correo", "error.usuario", "El correo ya está registrado.");
            }

            if (usuarioServicio.existeUsuario(user.getUsuario())) {
                result.rejectValue("usuario", "error.usuario", "El nombre de usuario ya está en uso.");
            }

            if (result.hasErrors()) {
                model.addAttribute("user", user);
                return "registro";
            }

            usuarioServicio.nuevoUsuario(user, null);
            return "redirect:/login?registroExitoso=true";

        } catch (Exception e) {
            model.addAttribute("error", "Error al registrar usuario");
            return "registro";
        }
    }

}

