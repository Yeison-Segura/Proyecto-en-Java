package proyecto.java.usuario.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import proyecto.java.usuario.modelo.Venta;
import proyecto.java.usuario.repositorio.VentaRepositorio;

@Service
@Transactional
public class VentaServicio implements IVentaServicio {
    
    @Autowired
    private VentaRepositorio ventaRep;
    
    @Override
    public List<Venta> getVentas() {
        return ventaRep.findAll();
    }

    @Override
    public void nuevaVenta(Venta venta) {
        ventaRep.save(venta);
    }

    @Override
    public Venta buscarVenta(Integer id) {
        return ventaRep.findById(id).orElse(null);
    }

    @Override
    public void borrarVenta(Integer id) {
        ventaRep.deleteById(id);
    }
}
