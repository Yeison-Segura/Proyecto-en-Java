package proyecto.java.usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
