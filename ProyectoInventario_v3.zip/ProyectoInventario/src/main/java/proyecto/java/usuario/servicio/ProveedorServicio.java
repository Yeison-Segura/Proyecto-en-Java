package proyecto.java.usuario.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import proyecto.java.usuario.modelo.Proveedor;
import proyecto.java.usuario.repositorio.ProveedorRepositorio;

@Service
@Transactional
public class ProveedorServicio implements IProveedorServicio{
	@Autowired
	ProveedorRepositorio provRep;
	
	@Override
	public List<Proveedor> getProveedores(){
		return provRep.findAll();
	}
	
	@Override
	public Proveedor nuevoProveedor(Proveedor proveedor){
		return provRep.save(proveedor);
	}

	@Override
	public Proveedor buscarProveedor(Integer id) {
		return provRep.findById(id).orElse(null);
	}

	@Override
	public void borrarProveedor(Integer id) {
		provRep.deleteById(id); 
	}
}
