package proyecto.java.usuario.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = Proveedor.TABLE_NAME)
public class Proveedor {
	public static final String TABLE_NAME = "proveedor";
	
    @NotNull(message = "El id del proveedor es obligatorio")
    @Id
    @Column(name = "p_id_proveedor")
    @Min(value = 1, message = "El id debe ser un número positivo")
    @Digits(integer = 11, fraction = 0, message = "El id debe tener máximo 11 dígitos")
    private Integer id;
    
    @NotBlank(message = "El nombre del proveedor es obligatorio")
    @Size(max = 30)
    @Column(name = "p_nombre_proveedor")
    private String nombre;
    
    @NotBlank(message = "El apellido del proveedor es obligatorio")
    @Size(max = 30)
    @Column(name = "p_apellido_proveedor")
    private String apellido;
    
    @NotBlank(message = "El nombre de la empresa es obligatorio")
    @Column(name = "p_empresa")
    @Size(max = 30)
    private String empresa;
    
    @NotBlank(message = "El telefono de contacto es obligatorio")
    @Column(name = "p_telefono")
    private String telefono;
    
    @NotBlank(message = "El correo del proveedor es obligatorio")
    @Email
    @Column(name = "p_correo")
    private String correo;

	
	public Proveedor() {
		super();
	}
	
	public Proveedor(
			@NotNull(message = "El id del proveedor es obligatorio") @Min(value = 1, message = "El id debe ser un número positivo") @Digits(integer = 11, fraction = 0, message = "El id debe tener máximo 11 dígitos") Integer id,
			@NotBlank(message = "El nombre del proveedor es obligatorio") @Size(max = 30) String nombre,
			@NotBlank(message = "El apellido del proveedor es obligatorio") @Size(max = 30) String apellido,
			@NotBlank(message = "El nombre de la empresa es obligatorio") @Size(max = 30) String empresa,
			@NotBlank(message = "El telefono de contacto es obligatorio") String telefono,
			@NotBlank(message = "El correo del proveedor es obligatorio") @Email String correo) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.empresa = empresa;
		this.telefono = telefono;
		this.correo = correo;
	}



	public Integer getId() {
	    return id;
	}

	public void setId(Integer id) {
	    this.id = id;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	
	
	
	
	
}
