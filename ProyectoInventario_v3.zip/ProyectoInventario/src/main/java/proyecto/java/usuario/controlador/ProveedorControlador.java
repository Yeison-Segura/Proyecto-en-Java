package proyecto.java.usuario.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import jakarta.validation.Valid;
import proyecto.java.usuario.modelo.Proveedor;
import proyecto.java.usuario.servicio.ProveedorServicio;


@Controller
@RequestMapping("/views/proveedor")
public class ProveedorControlador {
	@Autowired
	ProveedorServicio provServ;
	
	@GetMapping("/")
	public String verIndex(Model model) {
		List<Proveedor> listProveedores = provServ.getProveedores();
		model.addAttribute("listProveedores",listProveedores);
		return "/views/proveedor/proveedor";
	}
	
	@GetMapping("/new")
	public String verPagNuevoProv(Model model) {
		Proveedor p = new Proveedor();
		model.addAttribute("proveedor",p);
		return "/views/proveedor/nuevo_proveedor";
	}

	@PostMapping("/save/new")
	public String saveProveedor(@Valid @ModelAttribute("proveedor") Proveedor proveedor, BindingResult result, Model model) {
		if (result.hasErrors()) {	        
	        return "/views/proveedor/nuevo_proveedor";
	    }
        provServ.nuevoProveedor(proveedor);
        return "redirect:/views/proveedor/";
	    
	}
	
	@PostMapping("/save/edit")
	public String editProveedor(@Valid @ModelAttribute("proveedor") Proveedor proveedor, BindingResult result, Model model) {
		if (result.hasErrors()) {
	        return "/views/proveedor/editar_proveedor";
	    }
        provServ.nuevoProveedor(proveedor);
        return "redirect:/views/proveedor/";
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteProveedor(@PathVariable(name = "id") int id, Model model) {
		try {
			provServ.borrarProveedor(id);
			return "redirect:/views/proveedor/";
		} catch (DataIntegrityViolationException ex) {
			model.addAttribute("errorTitulo", "Error al eliminar proveedor");
			model.addAttribute("volver", "/views/proveedor/");
			model.addAttribute("pagina", "Proveedores");
	        model.addAttribute("errorMensaje", "No se puede eliminar el proveedor porque tiene productos asociados.");
	        model.addAttribute("errorDetalle", ex.getMostSpecificCause().getMessage());
	        return "error";
		}
		
	}
	
	@GetMapping("/editar/{id}")
	public String editarId(@PathVariable(name = "id") int id, Model model) {
		model.addAttribute("proveedor", provServ.buscarProveedor(id));
		return "/views/proveedor/editar_proveedor";
	}
	
}
