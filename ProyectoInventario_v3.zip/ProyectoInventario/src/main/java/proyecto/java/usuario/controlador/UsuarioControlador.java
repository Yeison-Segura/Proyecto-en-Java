package proyecto.java.usuario.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.validation.Valid;
import proyecto.java.usuario.modelo.Usuario;
import proyecto.java.usuario.servicio.UsuarioServicio;

@Controller
@RequestMapping("/views/usuario")
public class UsuarioControlador {

    @Autowired
    private UsuarioServicio usuarioServ;

    @GetMapping("/")
    public String verIndex(Model model) {
        List<Usuario> listUsuarios = usuarioServ.getUsuarios();
        model.addAttribute("listUsuarios", listUsuarios);
        return "/views/usuario/usuario"; 
    }

    @GetMapping("/new")
    public String verPagNuevoUsuario(Model model) {
        Usuario u = new Usuario();
        model.addAttribute("nuevoUsuario", u);
        return "/views/usuario/nuevo_usuario";
    }

    @PostMapping("/save/new")
    public String saveUsuario(@Valid @ModelAttribute("nuevoUsuario") Usuario usuario,
          BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "/views/usuario/nuevo_usuario";
        }

        usuarioServ.nuevoUsuario(usuario);
        return "redirect:/views/usuario/";
    }

    @GetMapping("/editar/{id}")
    public String editarUsuario(@PathVariable(name = "id") int id, Model model) {
        Usuario usuario = usuarioServ.buscarUsuario(id);
        model.addAttribute("editarUsuario", usuario);
        return "/views/usuario/editar_usuario";
    }

    @PostMapping("/save/edit")
    public String editUsuario(@Valid @ModelAttribute("editarUsuario") Usuario usuario,
           BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "/views/usuario/editar_usuario";
        }

        usuarioServ.nuevoUsuario(usuario);
        return "redirect:/views/usuario/";
    }

    @RequestMapping("/delete/{id}")
    public String deleteUsuario(@PathVariable(name = "id") int id, Model model) {
        try {
            usuarioServ.borrarUsuario(id);
            return "redirect:/views/usuario/";
        } catch (DataIntegrityViolationException ex) {
            model.addAttribute("errorTitulo", "Error al eliminar usuario");
            model.addAttribute("volver", "/views/usuario/");
            model.addAttribute("pagina", "Usuarios");
            model.addAttribute("errorMensaje", "No se puede eliminar el usuario porque tiene datos asociados.");
            model.addAttribute("errorDetalle", ex.getMostSpecificCause().getMessage());
            return "error";
        }
    }
}
