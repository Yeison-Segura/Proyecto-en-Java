package proyecto.java.usuario.servicio;

import java.util.List;
import proyecto.java.usuario.modelo.Usuario;

public interface IUsuarioServicio {
    
    public List<Usuario> getUsuarios();
    
    public void nuevoUsuario(Usuario usuario);
    
    public Usuario buscarUsuario(Integer id);
    
    public void borrarUsuario(Integer id);
}
