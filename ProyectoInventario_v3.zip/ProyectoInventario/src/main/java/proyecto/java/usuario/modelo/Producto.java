package proyecto.java.usuario.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = Producto.TABLE_NAME)
public class Producto {
	
	private static final String TABLE_NAME="producto";
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "p_id_producto")
    private int id;

	@NotBlank(message = "El color es obligatorio")
    @Size(max = 30)
    @Column(name = "p_color")
    private String color;

	@NotNull(message = "La cantidad es obligatoria")
	@Min(value = 0, message = "la cantidad no puede ser negativa")
    @Column(name = "p_cantidad")
    private int cantidad;

	@NotNull(message = "La talla es obligatoria")
	@Min(value = 10, message = "ingrese una talla valida desde 10")
    @Column(name = "p_talla")
    private int talla;

	@NotBlank(message = "La marca es obligatoria, sino hay marca ponga 'genericos'")
	@Size(max = 60)
    @Column(name = "p_marca")
    private String marca;
	
	@Size(max = 200)
    @Column(name = "p_descripcion")
    private String descripcion;
	
	@Min(value = 1, message = "ingrese un valor valido")
    @Column(name = "p_precio")
    private double precio;
    
	@NotNull(message = "Debe seleccionar un proveedor")
    @ManyToOne
    @JoinColumn(name = "p_id_proveedor", nullable = false) 
    private Proveedor proveedor;
	
	public Producto() {
		super();
	}

	public Producto(int id, @NotBlank(message = "El color es obligatorio") @Size(max = 30) String color,
			@NotNull(message = "La cantidad es obligatoria") @Min(value = 0, message = "la cantidad no puede ser negativa") int cantidad,
			@NotBlank(message = "La talla es obligatoria") @Min(value = 10, message = "la talla debe ser un número positivo") int talla,
			@NotBlank(message = "La marca es obligatoria, sino hay marca ponga 'genericos'") @Size(max = 60) String marca,
			@Size(max = 200) String descripcion, @Min(value = 1, message = "ingrese un valor valido") double precio,
			Proveedor proveedor) {
		super();
		this.id = id;
		this.color = color;
		this.cantidad = cantidad;
		this.talla = talla;
		this.marca = marca;
		this.descripcion = descripcion;
		this.precio = precio;
		this.proveedor = proveedor;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public int getTalla() {
		return talla;
	}

	public void setTalla(int talla) {
		this.talla = talla;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Proveedor getProveedor() {
		return proveedor;
	}

	public void setProveedor(Proveedor proveedor) {
		this.proveedor = proveedor;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", color=" + color + ", cantidad=" + cantidad + ", talla=" + talla + ", marca="
				+ marca + ", descripcion=" + descripcion + ", precio=" + precio + ", proveedor=" + proveedor + "]";
	}
	
	
}
