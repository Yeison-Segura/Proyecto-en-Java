package proyecto.java.usuario.servicio;

import java.util.List;
import proyecto.java.usuario.modelo.Venta;

public interface IVentaServicio {
    
    public List<Venta> getVentas();
    
    public void nuevaVenta(Venta venta);
    
    public Venta buscarVenta(Integer id);
    
    public void borrarVenta(Integer id);
}
