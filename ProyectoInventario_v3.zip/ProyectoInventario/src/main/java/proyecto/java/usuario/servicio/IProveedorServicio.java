package proyecto.java.usuario.servicio;

import java.util.List;

import proyecto.java.usuario.modelo.Proveedor;

public interface IProveedorServicio {
	
	List<Proveedor> getProveedores();
	
	Proveedor nuevoProveedor(Proveedor proveedor);
	
	Proveedor buscarProveedor(Integer id);
	
	void borrarProveedor(Integer id);
	
}
