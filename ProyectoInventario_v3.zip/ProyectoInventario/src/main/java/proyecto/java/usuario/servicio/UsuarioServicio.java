package proyecto.java.usuario.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import proyecto.java.usuario.modelo.Usuario;
import proyecto.java.usuario.repositorio.UsuarioRepositorio;

@Service
@Transactional
public class UsuarioServicio implements IUsuarioServicio {
	
	@Autowired
	private UsuarioRepositorio usuarioRep;
	
	@Override
	public List<Usuario> getUsuarios() {
		return usuarioRep.findAll();
	}

	@Override
	public void nuevoUsuario(Usuario usuario) {
		usuarioRep.save(usuario);
	}

	@Override
	public Usuario buscarUsuario(Integer id) {
		return usuarioRep.findById(id).orElse(null);
	}

	@Override
	public void borrarUsuario(Integer id) {
		usuarioRep.deleteById(id);		
	}
}
