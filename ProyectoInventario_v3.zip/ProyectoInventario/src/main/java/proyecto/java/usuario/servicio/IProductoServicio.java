package proyecto.java.usuario.servicio;

import java.util.List;

import proyecto.java.usuario.modelo.Producto;

public interface IProductoServicio {
	
	public List<Producto> getProductos();
	
	public void nuevoProducto(Producto prodcuto);
	
	public Producto buscarProducto(Integer id);
	
	public void borrarProducto(Integer id);
	
}
