package proyecto.java.usuario.controlador;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import jakarta.validation.Valid;
import proyecto.java.usuario.modelo.Venta;
import proyecto.java.usuario.modelo.Producto;
import proyecto.java.usuario.modelo.Cliente;
import proyecto.java.usuario.servicio.VentaServicio;
import proyecto.java.usuario.servicio.ProductoServicio;
import proyecto.java.usuario.servicio.ClienteServicio;

@Controller
@RequestMapping("/views/venta")
public class VentaControlador {
    
    @Autowired
    private VentaServicio ventaServ;
    
    @Autowired
    private ProductoServicio prodServ;
    
    @Autowired
    private ClienteServicio clienteServ;

    @GetMapping("/")
    public String verIndex(Model model) {
        List<Venta> listVentas = ventaServ.getVentas();
        model.addAttribute("listVentas", listVentas);
        return "/views/venta/venta";
    }

    @GetMapping("/new")
    public String verPagNuevaVenta(Model model) {
        Venta v = new Venta();
        List<Producto> listProductos = prodServ.getProductos();
        List<Cliente> listClientes = clienteServ.getClientes();
        model.addAttribute("listProductos", listProductos);
        model.addAttribute("listClientes", listClientes);
        model.addAttribute("venta", v);
        return "/views/venta/nueva_venta";
    }

    @PostMapping("/save/new")
    public String saveVenta(@Valid @ModelAttribute("venta") Venta venta,
                            BindingResult result, Model model) {
        if (result.hasErrors()) {
            List<Producto> listProductos = prodServ.getProductos();
            List<Cliente> listClientes = clienteServ.getClientes();
            model.addAttribute("listProductos", listProductos);
            model.addAttribute("listClientes", listClientes);
            return "/views/venta/nueva_venta";
        }
        
        // Calcular el total
        venta.setTotal(venta.getCantidad() * venta.getPrecioUnitario());
        ventaServ.nuevaVenta(venta);
        return "redirect:/views/venta/";
    }

    @GetMapping("/editar/{id}")
    public String editarVenta(@PathVariable(name = "id") int id, Model model) {
        List<Producto> listProductos = prodServ.getProductos();
        List<Cliente> listClientes = clienteServ.getClientes();
        model.addAttribute("listProductos", listProductos);
        model.addAttribute("listClientes", listClientes);
        model.addAttribute("venta", ventaServ.buscarVenta(id));
        return "/views/venta/editar_venta";
    }

    @PostMapping("/save/edit")
    public String editVenta(@Valid @ModelAttribute("venta") Venta venta,
                            BindingResult result, Model model) {
        if (result.hasErrors()) {
            List<Producto> listProductos = prodServ.getProductos();
            List<Cliente> listClientes = clienteServ.getClientes();
            model.addAttribute("listProductos", listProductos);
            model.addAttribute("listClientes", listClientes);
            return "/views/venta/editar_venta";
        }
        
        // Calcular el total
        venta.setTotal(venta.getCantidad() * venta.getPrecioUnitario());
        ventaServ.nuevaVenta(venta);
        return "redirect:/views/venta/";
    }

    @RequestMapping("/delete/{id}")
    public String deleteVenta(@PathVariable(name = "id") int id, Model model) {
        try {
            ventaServ.borrarVenta(id);
            return "redirect:/views/venta/";
        } catch (DataIntegrityViolationException ex) {
            model.addAttribute("errorTitulo", "Error al eliminar venta");
            model.addAttribute("volver", "/views/venta/");
            model.addAttribute("pagina", "Ventas");
            model.addAttribute("errorMensaje", "No se puede eliminar la venta.");
            model.addAttribute("errorDetalle", ex.getMostSpecificCause().getMessage());
            return "fallo";
        }
    }
}
