package proyecto.java.usuario.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import proyecto.java.usuario.modelo.Venta;

public interface VentaRepositorio extends JpaRepository<Venta, Integer> {

}
