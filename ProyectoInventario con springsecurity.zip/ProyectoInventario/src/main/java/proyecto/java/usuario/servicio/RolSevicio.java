package proyecto.java.usuario.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import proyecto.java.usuario.modelo.Rol;
import proyecto.java.usuario.repositorio.RolRepositorio;

@Service
@Transactional
public class RolSevicio implements IRolServicio {
	
	@Autowired
	RolRepositorio rolrep;

	@Override
	public List<Rol> getRoles() {
		return rolrep.findAll();
	}
	
	
	
}
