package proyecto.java.usuario.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import proyecto.java.usuario.modelo.Producto;
import proyecto.java.usuario.repositorio.ProductoRepositorio;

@Service
@Transactional
public class ProductoServicio implements IProductoServicio{
	
	@Autowired
	ProductoRepositorio prodRep;
	
	@Override
	public List<Producto> getProductos() {
		return prodRep.findAll();
	}

	@Override
	public void nuevoProducto(Producto producto) {
		prodRep.save(producto);
	}

	@Override
	public Producto buscarProducto(Integer id) {
		return prodRep.findById(id).orElse(null);
	}

	@Override
	public void borrarProducto(Integer id) {
		prodRep.deleteById(id);		
	}
 
}
