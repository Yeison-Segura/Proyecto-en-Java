package proyecto.java.usuario.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.validation.Valid;
import proyecto.java.usuario.modelo.Producto;
import proyecto.java.usuario.modelo.Proveedor;
import proyecto.java.usuario.servicio.ProductoServicio;
import proyecto.java.usuario.servicio.ProveedorServicio;

@Controller
@RequestMapping("/views/producto")
public class ProductosControlador {
	@Autowired
	ProductoServicio prodServ;
	
	@Autowired
	ProveedorServicio provServ;
	
	@GetMapping("/")
	public String verIndex(Model model) {
		List<Producto> listProductos = prodServ.getProductos();
		model.addAttribute("listProductos",listProductos);
		return "/views/producto/producto";
	}
	
	@GetMapping("/new")
	public String verPagNuevoProd(Model model) {
		Producto p = new Producto();
		List<Proveedor> listProveedores = provServ.getProveedores();
		model.addAttribute("listProveedores",listProveedores);
		model.addAttribute("producto",p);
		return "/views/producto/nuevo_producto";
	}

	@PostMapping("/save/new")
	public String saveProducto(@Valid @ModelAttribute("producto") Producto producto,BindingResult result, Model model) {
		if (result.hasErrors()) {
			List<Proveedor> listProveedores = provServ.getProveedores();
			model.addAttribute("listProveedores",listProveedores);
			return "/views/producto/nuevo_producto";
		}
		
		prodServ.nuevoProducto(producto);
		return "redirect:/views/producto/";
	}
	
	@PostMapping("/save/edit")
	public String editProducto(@Valid @ModelAttribute("producto") Producto producto,BindingResult result, Model model) {
		if (result.hasErrors()) {
			List<Proveedor> listProveedores = provServ.getProveedores();
			model.addAttribute("listProveedores",listProveedores);
			return "/views/producto/editar_producto";
		}
		
		prodServ.nuevoProducto(producto);
		return "redirect:/views/producto/";
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteProducto(@PathVariable(name = "id") int id, Model model) {
		try {
			prodServ.borrarProducto(id);
			return "redirect:/views/producto/";
		} catch (DataIntegrityViolationException ex) {
			model.addAttribute("errorTitulo", "Error al eliminar producto");
			model.addAttribute("volver", "/views/producto/");
			model.addAttribute("pagina", "Productos");
	        model.addAttribute("errorMensaje", "No se puede eliminar el producto porque tiene ventas asociadas.");
	        model.addAttribute("errorDetalle", ex.getMostSpecificCause().getMessage());
	        return "fallo";
		}
		
		
	}
	
	@GetMapping("/editar/{id}")
	public String editarId(@PathVariable(name = "id") int id, Model model) {
		List<Proveedor> listProveedores = provServ.getProveedores();
		model.addAttribute("listProveedores",listProveedores);
		model.addAttribute("producto", prodServ.buscarProducto(id));
		return "/views/producto/editar_producto";
	}
	
}
